/*jshint unused:false */

var require = {
	paths: {
		'qunit': [
			'../node_modules/qunitjs/qunit/qunit'
		]
	}
};
